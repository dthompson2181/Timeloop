﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ISM3232___Timeloop
{
    public partial class FormTimeloop : Form
    {
        public FormTimeloop()
        {
            InitializeComponent();
        }

        private void buttonSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                // Initialize variables for input and count.//
                int input = int.Parse(textBoxInput.Text);
                int count = 1;
                // Excecute the while loop.//
                while(count <= input)
                {
                    MessageBox.Show(count + " Abracadabra");
                    count = count + 1;
                }
                MessageBox.Show("You have now left the timeloop.");
            }
            catch
            {
                MessageBox.Show("You have an error.");
            }
        }
    }
}
